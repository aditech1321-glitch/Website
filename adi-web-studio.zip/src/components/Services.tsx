/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { agencyServices } from '../data';
import * as LucideIcons from 'lucide-react';

interface ServicesProps {
  onSelectService: (serviceName: string) => void;
}

export default function Services({ onSelectService }: ServicesProps) {
  const [activeCategory, setActiveCategory] = useState('All');

  // Dynamically group categories
  const categories = ['All', 'Retail & Shops', 'Local Business', 'Creative', 'Education'];

  const filteredServices = activeCategory === 'All'
    ? agencyServices
    : agencyServices.filter(s => s.category === activeCategory || s.id.includes(activeCategory.toLowerCase().replace(/\s+/g, '-')));

  // Helper function to render Lucide Icons dynamically based on search key
  const renderIcon = (name: string, className: string) => {
    // Typecast to any to allow dynamic lookup safely
    const IconComponent = (LucideIcons as any)[name];
    if (IconComponent) {
      return <IconComponent className={className} />;
    }
    return <LucideIcons.Globe className={className} />;
  };

  return (
    <section
      id="services"
      className="py-24 bg-[#030712] relative overflow-hidden"
    >
      {/* Background Gradients */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-blue-900/10 rounded-full blur-[100px] pointer-events-none -z-10" />
      <div className="absolute bottom-0 right-10 w-80 h-80 bg-indigo-900/5 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Content */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
            <LucideIcons.LayoutGrid className="w-3.5 h-3.5" />
            <span>Our Service Catalogue</span>
          </div>
          
          <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
            Tailored Development Strategies For{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Every Business Need
            </span>
          </h2>
          
          <p className="font-sans text-sm sm:text-base text-slate-400 mt-4 leading-relaxed">
            Choose from our specialized structures custom-engineered to convert your local foot traffic and digital visitors into paying, loyal clients.
          </p>
        </div>

        {/* Filter categories tabs */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-sans font-bold border transition-all duration-200 cursor-pointer outline-none ${
                activeCategory === cat
                  ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-500/10'
                  : 'bg-slate-900/40 border-slate-900 text-slate-400 hover:text-slate-200 hover:border-slate-800'
              }`}
              id={`service-cat-${cat.toLowerCase().replace(/\s+/g, '-')}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="services-grid">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group sleek-card p-6 flex flex-col justify-between hover:-translate-y-1.5"
              id={`service-card-${service.id}`}
            >
              <div>
                {/* Visual Header */}
                <div className="flex items-start justify-between">
                  <div className="w-12 h-12 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-500 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                    {renderIcon(service.iconName, 'w-6 h-6')}
                  </div>
                  <div className="text-right">
                    <span className="font-sans text-slate-500 text-xs uppercase font-bold tracking-wider block">
                      Starting AT
                    </span>
                    <span className="font-sans text-blue-400 font-extrabold text-base tracking-tight leading-none mt-1 block">
                      {service.price}
                    </span>
                  </div>
                </div>

                {/* Body Details */}
                <h3 className="font-sans font-bold text-lg text-white mt-6 group-hover:text-blue-400 transition-colors">
                  {service.title}
                </h3>
                
                <p className="font-sans text-xs text-slate-400 mt-2.5 leading-relaxed">
                  {service.description}
                </p>

                {/* Features list */}
                <div className="mt-6 pt-5 border-t border-slate-900/60">
                  <span className="font-mono text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-3">
                    Project Deliverables:
                  </span>
                  <ul className="space-y-2">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start text-xs text-slate-300">
                        <LucideIcons.Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-8 pt-5 border-t border-slate-900/60 flex items-center justify-between">
                <span className="flex items-center text-xs text-slate-400 font-mono">
                  <LucideIcons.Clock className="w-3.5 h-3.5 mr-1.5 text-blue-500" />
                  {service.deliveryTime}
                </span>
                
                <button
                  onClick={() => onSelectService(service.title)}
                  className="inline-flex items-center text-xs font-sans font-bold text-blue-400 hover:text-blue-300 transition-colors group/btn cursor-pointer"
                  id={`service-select-btn-${service.id}`}
                >
                  Configure Website
                  <LucideIcons.ArrowRight className="w-3.5 h-3.5 ml-1 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
