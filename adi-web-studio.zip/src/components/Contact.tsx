/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Copy, CheckCircle2, MessageSquare, Send, Sparkles, Clock } from 'lucide-react';

interface ContactProps {
  prefilledPlan?: string;
  prefilledPrice?: number;
  prefilledDetails?: string;
  onClearPrefill?: () => void;
}

export default function Contact({ prefilledPlan, prefilledPrice, prefilledDetails, onClearPrefill }: ContactProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    service: 'Pharmacy Websites',
    requirements: '',
    budget: '₹5,000'
  });

  const [copied, setCopied] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  const [submittedData, setSubmittedData] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Apply prefilled parameters from pricing estimator
  useEffect(() => {
    if (prefilledPlan) {
      setFormData((prev) => ({
        ...prev,
        service: prefilledPlan,
        requirements: prefilledDetails || '',
        budget: prefilledPrice ? `₹${prefilledPrice.toLocaleString('en-IN')}` : '₹5,000'
      }));
    }
  }, [prefilledPlan, prefilledPrice, prefilledDetails]);

  // Copy email helper
  const handleCopyEmail = () => {
    navigator.clipboard.writeText('aditech1321@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError(null);

    // Store in localStorage for client-side persistence
    const newInquiry = {
      id: 'inq-' + Date.now(),
      ...formData,
      timestamp: new Date().toISOString()
    };

    try {
      const response = await fetch("https://formsubmit.co/ajax/aditech1321@gmail.com", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          "Name": formData.name,
          "Email": formData.email,
          "Business Name": formData.company || "N/A",
          "Website Type Requested": formData.service,
          "Budget Selection": formData.budget,
          "Specific Requirements": formData.requirements || "None provided",
          "_subject": `New Website Inquiry: ${formData.service} from ${formData.name}`,
          "_replyto": formData.email
        })
      });

      if (!response.ok) {
        throw new Error("Unable to forward message. Please check connection and try again.");
      }

      const result = await response.json();
      if (result.success === 'false' || result.success === false) {
        throw new Error(result.message || "Unable to forward message. Please try again.");
      }

      const existing = JSON.parse(localStorage.getItem('adi_agency_inquiries') || '[]');
      existing.push(newInquiry);
      localStorage.setItem('adi_agency_inquiries', JSON.stringify(existing));

      setSubmittedData(newInquiry);
      setSubmissionSuccess(true);

      // Clear prefill on parent if applicable
      if (onClearPrefill) {
        onClearPrefill();
      }
    } catch (err: any) {
      console.error("Form submit error:", err);
      setSubmitError(err.message || "An unexpected error occurred. Please try again or email us directly at aditech1321@gmail.com.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setFormData({
      name: '',
      email: '',
      company: '',
      service: 'Pharmacy Websites',
      requirements: '',
      budget: '₹5,000'
    });
    setSubmissionSuccess(false);
    setSubmittedData(null);
  };

  return (
    <section
      id="contact"
      className="py-24 bg-[#030712] relative overflow-hidden text-left"
    >
      {/* Background gradients */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Launch Your Digital Hub</span>
          </div>
          
          <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
            Start Growing Your{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400 font-extrabold">
              Brand Online
            </span>
          </h2>
          
          <p className="font-sans text-sm text-slate-400 mt-4 leading-relaxed">
            Fill out our premium web query briefing. We return complete wireframe strategies and customized estimates inside 2 hours completely free of obligation!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12" id="contact-wrapper">
          {/* Left panel: Info Coordinates */}
          <div className="lg:col-span-4 space-y-6 flex flex-col justify-between">
            <div className="space-y-6">
              <h3 className="font-sans font-extrabold text-xl text-white">
                Contact Information
              </h3>
              
              <p className="font-sans text-xs sm:text-sm text-slate-400 leading-relaxed">
                We design premium digital properties for startups, local pharmacies, tuition managers, creative artists, and local restaurants across regions.
              </p>

              {/* Coordinator metrics blocks */}
              <div className="space-y-4 pt-4">
                {/* Email block */}
                <div className="flex items-start gap-4 p-4 sleek-card relative group">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500 shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="space-y-1.5 max-w-full truncate">
                    <span className="font-mono text-[10px] text-slate-505 uppercase tracking-wider font-semibold block leading-none">
                      Support Email
                    </span>
                    <span className="font-sans text-xs sm:text-sm text-white font-bold block truncate">
                      aditech1321@gmail.com
                    </span>
                    
                    {/* Clipboard copy helper */}
                    <button
                      onClick={handleCopyEmail}
                      className="absolute top-4 right-4 p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-md text-slate-400 hover:text-white transition-all cursor-pointer focus:outline-none"
                      title="Copy email to clipboard"
                      id="copy-email-btn"
                    >
                      {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    {copied && (
                      <span className="font-mono text-[9px] text-emerald-400 font-bold block mt-1 animate-pulse">
                        ✓ Copied to clipboard!
                      </span>
                    )}
                  </div>
                </div>

                {/* Response speed block */}
                <div className="flex items-start gap-4 p-4 sleek-card">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600/10 flex items-center justify-center text-emerald-500 shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-slate-505 uppercase tracking-wider font-semibold block leading-none">
                      Avg Response Speed
                    </span>
                    <span className="font-sans text-xs sm:text-sm text-white font-bold block mt-1.5">
                      Under 2 Hours (Fast Priority)
                    </span>
                  </div>
                </div>

                {/* Operations location block */}
                <div className="flex items-start gap-4 p-4 sleek-card">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600/10 flex items-center justify-center text-indigo-500 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-mono text-[10px] text-slate-505 uppercase tracking-wider font-semibold block leading-none">
                      Studio Coverage
                    </span>
                    <span className="font-sans text-xs sm:text-sm text-white font-bold block mt-1.5">
                      Remote Consultation & Delivery Across India
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Premium Guarantee display footer inside info col */}
            <div className="sleek-card p-5 bg-gradient-to-br from-blue-950/20 to-slate-950/40 border border-blue-500/10 rounded-2xl">
              <div className="flex gap-3">
                <Sparkles className="w-6 h-6 text-blue-400 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <h4 className="font-sans font-bold text-xs text-white">Adi Web Studio Assurance</h4>
                  <p className="font-sans text-[11px] text-slate-400 mt-1 leading-relaxed">
                    No upfront setup deposits required until we complete your custom initial home mockup design live!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right panel: Grand interactive Contact Form */}
          <div className="lg:col-span-8 sleek-card p-6 sm:p-10 relative">
            
            {/* If estimate is currently loaded, display alert banner inside form */}
            {prefilledPlan && !submissionSuccess && (
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-xl p-4 mb-6 flex items-center justify-between text-xs text-blue-400 font-sans font-semibold">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4.5 h-4.5 text-blue-400 animate-pulse" />
                  <span>Interactive Pricing Estimate Loaded: {prefilledPlan} - {formData.budget}</span>
                </div>
                <button
                  onClick={onClearPrefill}
                  className="text-[11px] font-bold text-slate-400 hover:text-white underline focus:outline-none cursor-pointer"
                  id="estimator-clear-prefill-btn"
                >
                  Reset Prefill
                </button>
              </div>
            )}

            {/* SUCCESS STATE ENVELOPE */}
            {submissionSuccess ? (
              <div className="py-12 px-4 flex flex-col items-center text-center space-y-6" id="contact-success-overlay">
                <div className="w-16 h-16 rounded-full bg-emerald-600/15 flex items-center justify-center text-emerald-400 border border-emerald-500/25 shadow-lg shadow-emerald-500/10">
                  <CheckCircle2 className="w-9 h-9" />
                </div>
                
                <h3 className="font-sans font-extrabold text-2xl text-white">
                  Briefing Received Successfully!
                </h3>
                
                <p className="font-sans text-xs sm:text-sm text-slate-400 max-w-lg leading-relaxed">
                  Thank you, <strong className="text-white">{submittedData?.name}</strong>. Your custom web requirements for <strong className="text-blue-400">{submittedData?.service}</strong> is now securely indexed. Our engineering team will review details and mail a complete wireframe sketch to <strong className="text-white">{submittedData?.email}</strong> in under 2 hours!
                </p>

                {/* Submitted overview recap */}
                <div className="bg-slate-950 p-4 border border-slate-900 rounded-xl text-left max-w-md w-full space-y-2 font-mono text-[11px]">
                  <span className="text-slate-500 block text-center border-b border-slate-900 pb-1 uppercase font-bold tracking-widest text-[9px]">
                    Briefing Receipt Recap
                  </span>
                  <div><span className="text-slate-500">Service:</span> <span className="text-blue-300 font-bold">{submittedData?.service}</span></div>
                  <div><span className="text-slate-500">Estimated Budget:</span> <span className="text-emerald-400 font-bold">{submittedData?.budget}</span></div>
                  <div><span className="text-slate-500">Target Company:</span> <span className="text-slate-300">{submittedData?.company || 'Local Business'}</span></div>
                  {submittedData?.requirements && (
                    <div><span className="text-slate-500">Specs:</span> <span className="text-slate-400 block max-h-[80px] overflow-y-auto mt-1 leading-normal">{submittedData?.requirements}</span></div>
                  )}
                </div>

                {/* FormSubmit Verification Notice */}
                <div className="bg-blue-500/5 border border-blue-500/10 p-4 rounded-xl text-left max-w-md w-full flex gap-3">
                  <Sparkles className="w-5 h-5 text-blue-400 shrink-0 mt-0.5 animate-pulse" />
                  <div className="font-sans text-[11px] text-slate-400 leading-normal">
                    <strong className="text-blue-300 block mb-0.5">📬 Check Your Gmail Inbox (Action Required)</strong>
                    Since this is sent via FormSubmit directly to your GMail, you will receive a one-time activation link at <strong className="text-white">aditech1321@gmail.com</strong>. Simply open your Gmail, click <strong className="text-blue-400">"Activate"</strong>, and any future requests filled in this form will land straight in your inbox!
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    onClick={handleResetForm}
                    className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-bold rounded-xl border border-slate-800 cursor-pointer outline-none transition-colors"
                    id="success-new-briefing"
                  >
                    Submit Custom Briefing
                  </button>
                </div>
              </div>
            ) : (
              /* THE FORM */
              <form onSubmit={handleSubmit} className="space-y-6" id="contact-agency-form">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Name field */}
                  <div className="space-y-2">
                    <label htmlFor="form-name" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Full Name *
                    </label>
                    <input
                      id="form-name"
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      placeholder="e.g. Ramesh Sharma"
                      className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white placeholder-slate-600 focus:outline-none font-sans disabled:opacity-50"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-2">
                    <label htmlFor="form-email" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Email Address *
                    </label>
                    <input
                      id="form-email"
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      placeholder="e.g. aditech1321@gmail.com"
                      className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white placeholder-slate-600 focus:outline-none font-sans disabled:opacity-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Business info */}
                  <div className="space-y-2">
                    <label htmlFor="form-company" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Business or Shop Name
                    </label>
                    <input
                      id="form-company"
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      placeholder="e.g. Sanjeevani Pharmacy"
                      className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white placeholder-slate-600 focus:outline-none font-sans disabled:opacity-50"
                    />
                  </div>

                  {/* Service tier type picker */}
                  <div className="space-y-2">
                    <label htmlFor="form-service" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Which type of website do you want? *
                    </label>
                    <select
                      id="form-service"
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white focus:outline-none font-sans cursor-pointer disabled:opacity-50"
                    >
                      <option value="Pharmacy Websites">Pharmacy Website (₹5,000)</option>
                      <option value="Restaurant Websites">Restaurant Website (₹5,000)</option>
                      <option value="Education Websites">Education Website (₹5,000)</option>
                      <option value="Portfolio Websites">Portfolio Website (₹4,000)</option>
                      <option value="Saloon Shops Websites">Saloon Shop Website (₹4,000)</option>
                      <option value="Grocery Shops Websites">Grocery Shop Website (₹4,000)</option>
                      <option value="Footwear Shops Websites">Footwear Shop Website (₹4,000)</option>
                      <option value="Clothing Shops Websites">Clothing Shop Website (₹4,000)</option>
                      <option value="Other Custom Requirements">Other Custom Website</option>
                    </select>
                  </div>
                </div>

                {/* Budget selection tracker */}
                <div className="space-y-2">
                  <label htmlFor="form-budget" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                    Estimated Budget Allocation
                  </label>
                  <select
                    id="form-budget"
                    name="budget"
                    value={formData.budget}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white focus:outline-none font-sans cursor-pointer disabled:opacity-50"
                  >
                    <option value="₹4,005">Under ₹4,000</option>
                    <option value="₹4,000">₹4,000 - Starter Plan</option>
                    <option value="₹5,000">₹5,000 - Professional Plan</option>
                    <option value="₹6,000">₹6,000 - Premium Plan</option>
                    <option value="Above ₹6,000">Above ₹6,000 (Complex Webapps)</option>
                  </select>
                </div>

                {/* Core description text box */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label htmlFor="form-requirements" className="font-sans text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      Specific Requirements & Deliverables
                    </label>
                    <span className="font-mono text-[10px] text-slate-500">Optional</span>
                  </div>
                  <textarea
                    id="form-requirements"
                    name="requirements"
                    rows={4}
                    value={formData.requirements}
                    onChange={handleChange}
                    disabled={isSubmitting}
                    placeholder="e.g. We require a 5-page layout for our pharmacy. Needs an upload form for doctor prescriptions, local maps sync, and mobile adaptive layout."
                    className="w-full px-4 py-3 input-sleek text-xs sm:text-sm text-white placeholder-slate-600 focus:outline-none font-sans resize-y disabled:opacity-50"
                  />
                </div>

                {submitError && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-xs font-sans font-bold text-red-400">
                    ⚠️ {submitError}
                  </div>
                )}

                {/* Submission CTA handle */}
                <div>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-4 px-4 bg-blue-600 hover:bg-blue-500 text-white font-sans font-bold rounded-xl sleek-button-glow active:scale-98 transition-all cursor-pointer outline-none disabled:opacity-50 disabled:cursor-not-allowed"
                    id="form-submit-btn"
                  >
                    <span>{isSubmitting ? "Sending Briefing..." : "Submit & Request Free Consultation"}</span>
                    {!isSubmitting && <Send className="w-4 h-4 ml-1" />}
                  </button>
                  <p className="text-[10px] text-slate-550 text-center block mt-3 font-semibold font-sans">
                    By submitting, you agree to receive direct design wireframe drafts and custom quotes on mail. Under 2h turnaround.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>

      </div>
    </section>
  );
}
