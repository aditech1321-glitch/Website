/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { clientTestimonials } from '../data';
import { Star, ChevronLeft, ChevronRight, MessageSquare, Quote } from 'lucide-react';

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % clientTestimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + clientTestimonials.length) % clientTestimonials.length);
  };

  const activeReview = clientTestimonials[currentIndex];

  return (
    <section
      id="testimonials"
      className="py-24 bg-[#030712] relative overflow-hidden"
    >
      {/* Background gradients */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Client Achievements</span>
          </div>
          
          <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
            Loved By Hard-working{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Local Owners
            </span>
          </h2>
          
          <p className="font-sans text-sm text-slate-400 mt-4 leading-relaxed">
            Read success stories from independent business entrepreneurs who upgraded their outdated systems to custom high-converting web layouts.
          </p>
        </div>

        {/* Testimonials Slider Framework */}
        <div className="relative sleek-card p-6 sm:p-10" id="testimonial-slider-container">
          {/* Quote floating icon */}
          <div className="absolute -top-6 -left-2 sm:left-8 w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
            <Quote className="w-6 h-6 rotate-180" />
          </div>

          <div className="min-h-[220px] flex flex-col justify-between text-left pt-3">
            {/* Review feedback */}
            <div className="space-y-4">
              {/* Star Rating Panel */}
              <div className="flex items-center space-x-1">
                {[...Array(activeReview.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-500" />
                ))}
              </div>

              {/* Review Text */}
              <p className="font-sans text-sm sm:text-base md:text-lg text-slate-200 leading-relaxed italic">
                "{activeReview.comment}"
              </p>
            </div>

            {/* Author Profile block */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-8 pt-6 border-t border-slate-900/60">
              <div className="flex items-center space-x-3">
                {/* Initials Avatar icon */}
                <div className="w-11 h-11 rounded-xl bg-blue-600/10 border border-blue-500/35 flex items-center justify-center font-sans font-extrabold text-xs text-blue-400 tracking-wider">
                  {activeReview.initials}
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-white leading-none">
                    {activeReview.name}
                  </h4>
                  <span className="font-sans text-[11px] text-slate-500 block mt-1 leading-none">
                    {activeReview.role}, <span className="text-blue-400 font-semibold">{activeReview.company}</span>
                  </span>
                </div>
              </div>

              {/* Prev / Next controls */}
              <div className="flex items-center space-x-1.5 self-end sm:self-auto">
                <button
                  onClick={prevTestimonial}
                  className="w-10 h-10 rounded-lg border border-slate-900 bg-slate-950 hover:bg-slate-900 hover:border-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-all cursor-pointer outline-none focus:ring-2 focus:ring-blue-500/40"
                  aria-label="Previous Testimonial"
                  id="testimonial-prev-btn"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="px-3.5 text-xs font-mono font-semibold text-slate-500 uppercase tracking-widest select-none">
                  {currentIndex + 1} / {clientTestimonials.length}
                </div>
                <button
                  onClick={nextTestimonial}
                  className="w-10 h-10 rounded-lg border border-slate-900 bg-slate-950 hover:bg-slate-900 hover:border-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-all cursor-pointer outline-none focus:ring-2 focus:ring-blue-500/40"
                  aria-label="Next Testimonial"
                  id="testimonial-next-btn"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Small client brand support strip */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 opacity-40 grayscale hover:opacity-75 transition-opacity duration-300">
          <span className="font-sans font-extrabold text-xs tracking-wider uppercase text-slate-400">Sanjeevani Rx</span>
          <span className="font-sans font-extrabold text-xs tracking-wider uppercase text-slate-400">Zenith Class</span>
          <span className="font-sans font-extrabold text-xs tracking-wider uppercase text-slate-400">The Clay Oven</span>
          <span className="font-sans font-extrabold text-xs tracking-wider uppercase text-slate-400">Apex Labs Co</span>
        </div>

      </div>
    </section>
  );
}
