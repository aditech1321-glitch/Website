/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Mail, Shield, CheckCircle2, ChevronUp, Sparkles } from 'lucide-react';

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-900 pt-16 pb-8 text-left text-xs text-slate-400 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 pb-12 border-b border-slate-900">
          
          {/* Logo & Description */}
          <div className="md:col-span-5 space-y-4">
            <a
              href="#home"
              onClick={(e) => handleLinkClick(e, 'home')}
              className="flex items-center space-x-2 group focus:outline-none"
              id="footer-logo"
            >
              <div className="w-8 h-8 flex items-center justify-center bg-blue-600 rounded-lg text-white">
                <Sparkles className="w-4.5 h-4.5" />
              </div>
              <span className="font-sans font-bold text-base text-white tracking-tight">
                Adi Web <span className="text-blue-500">Studio</span>
              </span>
            </a>
            
            <p className="font-sans text-xs text-slate-400 leading-relaxed max-w-sm">
              We design and write ultra-modern, high-converting websites starting at flat, affordable rates. Specifically tailored to help pharmacy stalls, tuition academies, restaurants, and startups scale conversions securely.
            </p>

            <div className="flex items-center space-x-2 bg-slate-900 border border-slate-900 rounded-xl px-3.5 py-2 w-fit">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span className="font-sans text-[10px] text-slate-300 font-semibold uppercase tracking-wide">
                Flat Pricing model
              </span>
            </div>
          </div>

          {/* Sitemap navigation */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-slate-505">
              Quick Navigation
            </h4>
            <ul className="space-y-2.5 font-sans">
              <li>
                <a
                  href="#home"
                  onClick={(e) => handleLinkClick(e, 'home')}
                  className="hover:text-white transition-colors"
                  id="footer-link-home"
                >
                  Home Landing
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  onClick={(e) => handleLinkClick(e, 'services')}
                  className="hover:text-white transition-colors"
                  id="footer-link-services"
                >
                  Our Services Catalog
                </a>
              </li>
              <li>
                <a
                  href="#pricing"
                  onClick={(e) => handleLinkClick(e, 'pricing')}
                  className="hover:text-white transition-colors"
                  id="footer-link-pricing"
                >
                  Transparent Plans
                </a>
              </li>
              <li>
                <a
                  href="#about"
                  onClick={(e) => handleLinkClick(e, 'about')}
                  className="hover:text-white transition-colors"
                  id="footer-link-about"
                >
                  Our Vision & About
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  onClick={(e) => handleLinkClick(e, 'contact')}
                  className="hover:text-white transition-colors"
                  id="footer-link-contact"
                >
                  Request Consultation
                </a>
              </li>
            </ul>
          </div>

          {/* Contact coordinates */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-slate-505">
              Studio Inquiry
            </h4>
            <ul className="space-y-3 font-sans">
              <li className="flex items-start text-xs text-slate-400">
                <Mail className="w-4 h-4 text-blue-500 mr-2.5 mt-0.5 shrink-0" />
                <div>
                  <span className="block font-semibold text-white leading-none">Inquiry Desk:</span>
                  <a href="mailto:aditech1321@gmail.com" className="hover:text-blue-400 transition-colors block mt-1">
                    aditech1321@gmail.com
                  </a>
                </div>
              </li>
              <li className="flex items-start text-xs text-slate-400">
                <Shield className="w-4 h-4 text-blue-500 mr-2.5 mt-0.5 shrink-0" />
                <div>
                  <span className="block font-semibold text-white leading-none">Working Hours:</span>
                  <span className="block mt-1">Mon - Sat (10:00 AM - 08:00 PM)</span>
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Footer Base bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[10px] text-slate-505 uppercase tracking-wider">
          <div>
            &copy; {new Date().getFullYear()} Adi Web Studio. All Rights Reserved.
          </div>
          <div>
            Designed with <span className="text-red-500 font-bold">♥</span> for Small Businesses
          </div>
          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-1 bg-slate-900 hover:bg-slate-850 px-3 py-1.5 rounded-lg border border-slate-900 hover:border-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer outline-none"
            id="footer-to-top-btn"
          >
            <span>Back to top</span>
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
}
