/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, ArrowRight, CheckCircle2, ShieldCheck, Zap, Laptop, Command } from 'lucide-react';

interface HeroProps {
  onQuoteClick: () => void;
  onPricingClick: () => void;
}

export default function Hero({ onQuoteClick, onPricingClick }: HeroProps) {
  const [activeTab, setActiveTab] = useState<'restaurant' | 'pharmacy' | 'education' | 'portfolio'>('restaurant');

  // Preview content according to business segments mentioned in request
  const previews = {
    restaurant: {
      tag: 'Local Restaurant',
      title: 'Spicy Oven Restaurant',
      color: 'from-orange-500 to-amber-600',
      accentColor: 'text-orange-500',
      menu: ['Paneer Tikka', 'Tandoori Roti', 'Dal Makhani', 'Butter Masala'],
      heroText: 'Savor Delicious Flavors In Town',
      btnText: 'Book Table Online'
    },
    pharmacy: {
      tag: 'Healthcare & Pharmacy',
      title: 'Sanjeevani Local Pharmacy',
      color: 'from-emerald-500 to-teal-600',
      accentColor: 'text-emerald-500',
      menu: ['Upload Prescription', 'Order Medicines', 'Consult Pharmacist', 'Home Delivery'],
      heroText: 'Your Trusted Health & Wellness Partner',
      btnText: 'Upload Rx Prescription'
    },
    education: {
      tag: 'Tuition & Academics',
      title: 'Zenith Academic Classes',
      color: 'from-purple-500 to-blue-600',
      accentColor: 'text-purple-500',
      menu: ['Class 9-10 Batch', 'Science & Mathematics', 'Individual Mentoring', 'Mock Exams Planner'],
      heroText: 'Unlocking Academic Excellence Easily',
      btnText: 'Enrol Free Trial'
    },
    portfolio: {
      tag: 'Portfolio & Creative',
      title: 'Vikram Creative Studio',
      color: 'from-pink-500 to-rose-600',
      accentColor: 'text-pink-500',
      menu: ['UX/UI Portfolio', 'Brand Styling Layouts', 'Commercial Photography', 'Contact Me'],
      heroText: 'Bespoke Premium Visual Experiences',
      btnText: 'View My Portfolio'
    }
  };

  return (
    <section
      id="home"
      className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden bg-[#020617]"
    >
      {/* Dynamic Background Gradients */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] -z-10 pointer-events-none" />
      <div className="absolute top-[20%] right-10 w-[600px] h-[600px] bg-indigo-600/5 rounded-full blur-[140px] -z-10 pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-[300px] h-[300px] bg-sky-500/10 rounded-full blur-[100px] -z-10 pointer-events-none" />

      {/* Grid Pattern Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] opacity-35 -z-20 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Text Content */}
          <div className="lg:col-span-7 flex flex-col space-y-8 text-left">
            {/* Tag Badge */}
            <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/30 text-blue-400 font-sans text-xs font-semibold px-3 py-1.5 rounded-full w-fit">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Modern Websites Worth ₹50k+ Starting At Just ₹4,000</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-sans font-extrabold text-white text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-[1.1] !mt-2">
              Professional Websites That Help Your{' '}
              <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-400">
                Business Grow
              </span>
            </h1>

            {/* Subheadline */}
            <p className="font-sans text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Get a modern, mobile-friendly website designed to attract customers, build trust, and increase sales. Tailored specifically for pharmacies, restaurants, tuition or education classes, salons, portfolios, grocery stores, footwear shops, and clothing boutiques.
            </p>

            {/* Quick trust bullet list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center space-x-2.5 text-slate-300 text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>Delivery in under 5 days</span>
              </div>
              <div className="flex items-center space-x-2.5 text-slate-300 text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>Mobile-Optimized & fast loading</span>
              </div>
              <div className="flex items-center space-x-2.5 text-slate-300 text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>No hidden fees + Free setup support</span>
              </div>
              <div className="flex items-center space-x-2.5 text-slate-300 text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>Modern UX worth thousands of dollars</span>
              </div>
            </div>

            {/* Buttons Row */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                onClick={onQuoteClick}
                className="group w-full sm:w-auto inline-flex items-center justify-center px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-sans font-bold rounded-xl transition-all sleek-button-glow hover:-translate-y-0.5 active:translate-y-0 active:scale-95 outline-none cursor-pointer focus:ring-4 focus:ring-blue-500/30"
                id="hero-quote-btn"
              >
                <span>Get Free Quote</span>
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onPricingClick}
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3.5 bg-white/[0.04] hover:bg-white/[0.08] text-white font-sans font-semibold rounded-xl border border-white/10 hover:border-white/20 transition-all hover:-translate-y-0.5 active:translate-y-0 outline-none cursor-pointer focus:ring-4 focus:ring-slate-800"
                id="hero-pricing-btn"
              >
                <span>View Pricing Plans</span>
              </button>
            </div>

            {/* Trust badges / stats */}
            <div className="flex flex-wrap items-center gap-x-8 gap-y-4 pt-6 border-t border-slate-900/80">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-blue-500" />
                <span className="text-xs font-mono font-semibold text-slate-400 tracking-wide uppercase">
                  100% Trusted
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-5 h-5 text-amber-500" />
                <span className="text-xs font-mono font-semibold text-slate-400 tracking-wide uppercase">
                  Supercharged Speed
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Laptop className="w-5 h-5 text-purple-500" />
                <span className="text-xs font-mono font-semibold text-slate-400 tracking-wide uppercase">
                  Custom Coded
                </span>
              </div>
            </div>
          </div>

          {/* Right Side: Interactive Website Preview Mockup */}
          <div className="lg:col-span-5 relative w-full" id="hero-mockup-wrapper">
            {/* Ambient Background Glow behind the editor mock */}
            <div className="absolute inset-0 bg-blue-500/10 rounded-2xl blur-3xl -z-10" />

            {/* Header switcher tabs */}
            <div className="flex flex-wrap gap-1.5 p-1.5 bg-slate-950/80 border border-slate-800 rounded-xl mb-4 shadow-xl">
              {(Object.keys(previews) as Array<keyof typeof previews>).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 min-w-[80px] text-center py-2 px-2.5 rounded-lg text-xs font-sans font-bold transition-all ${
                    activeTab === tab
                      ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  id={`hero-tab-${tab}`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            {/* Glassmorphic Project Mockup Frame */}
            <div className="sleek-card overflow-hidden text-left flex flex-col min-h-[360px] transform hover:scale-[1.01] transition-transform duration-300">
              {/* Mock Browser Header Bar */}
              <div className="bg-slate-950/40 border-b border-white/5 px-4 py-3.5 flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <span className="w-3 h-3 bg-rose-500/80 rounded-full inline-block" />
                  <span className="w-3 h-3 bg-amber-500/80 rounded-full inline-block" />
                  <span className="w-3 h-3 bg-emerald-500/80 rounded-full inline-block" />
                </div>
                <div className="bg-slate-950 border border-slate-900/80 rounded-md px-3 py-1 font-mono text-[10px] text-slate-400 text-center w-3/5 truncate">
                  {previews[activeTab].title.toLowerCase().replace(/\s+/g, '')}.com
                </div>
                <div className="w-6 h-6 flex items-center justify-center bg-slate-900 rounded border border-slate-800">
                  <span className="text-[10px] font-mono text-slate-500">★</span>
                </div>
              </div>

              {/* Mock Website Canvas Body */}
              <div className="p-5 flex-grow flex flex-col justify-between relative bg-slate-950/40">
                {/* Background ambient lighting in the preview based on chosen tab */}
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-b ${previews[activeTab].color} opacity-5 blur-2xl rounded-full`} />

                <div>
                  {/* Industry tag */}
                  <span className="font-sans font-extrabold text-[10px] uppercase tracking-wider text-blue-400 bg-blue-900/20 border border-blue-800/35 px-2.5 py-1 rounded">
                    {previews[activeTab].tag}
                  </span>

                  {/* Brand Title */}
                  <h3 className="font-sans font-bold text-xl text-white mt-4 tracking-tight italic border border-[#1800e6]" id="hero-mockup-title">
                    {previews[activeTab].title}
                  </h3>

                  {/* High Converting Sub */}
                  <p className="font-sans text-xs text-slate-400 mt-2 italic leading-relaxed max-w-[90%]">
                    "{previews[activeTab].heroText}"
                  </p>

                  <div className="mt-5">
                    <span className="font-mono text-[10px] text-slate-400 tracking-wider uppercase font-semibold block mb-2">
                      Key Pages & Capabilities:
                    </span>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      {previews[activeTab].menu.map((menuItem, idx) => (
                        <div
                          key={idx}
                          className="flex items-center space-x-1.5 p-1.5 bg-slate-900/60 border border-slate-800/40 rounded-lg text-[11px] text-slate-300"
                        >
                          <span className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${previews[activeTab].color}`} />
                          <span className="truncate">{menuItem}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-6 mt-4 border-t border-slate-900/80">
                  {/* Performance indicator snippet */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-slate-500">
                      <Command className="w-3.5 h-3.5" />
                      <span className="font-mono text-[10px] uppercase tracking-wider">Site Metrics</span>
                    </div>
                    <div className="flex gap-3">
                      <div className="flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                        <span className="font-mono text-[10px] text-slate-300 font-bold">LCP: 0.8s</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                        <span className="font-mono text-[10px] text-slate-300 font-bold">SEO: 100/100</span>
                      </div>
                    </div>
                  </div>

                  {/* Beautiful Mock button matching selected palette */}
                  <div className="flex items-center justify-between">
                    <span className="font-sans text-xs text-slate-400 font-medium">
                      Design Value: <span className="text-emerald-400 font-bold">High Convert</span>
                    </span>
                    <button
                      className={`inline-flex items-center justify-center px-4 py-2 bg-gradient-to-r ${previews[activeTab].color} text-white font-sans text-xs font-bold rounded-lg shadow-md pointer-events-none`}
                    >
                      <span>{previews[activeTab].btnText}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
