/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { pricingPlans } from '../data';
import { Check, X, Sliders, Calculator, ArrowRight, HelpCircle, Sparkles } from 'lucide-react';

interface PricingProps {
  onSelectPlanAndPrice: (planName: string, calculatedPrice: number, detailsText: string) => void;
}

export default function Pricing({ onSelectPlanAndPrice }: PricingProps) {
  // Config state for the Interactive Estimator
  const [selectedPlanId, setSelectedPlanId] = useState<'starter' | 'professional' | 'premium'>('professional');
  const [pagesCount, setPagesCount] = useState(5);
  const [includeSEO, setIncludeSEO] = useState(true);
  const [includeCMS, setIncludeCMS] = useState(false);
  const [includeSpeedOpt, setIncludeSpeedOpt] = useState(true);
  const [expressDelivery, setExpressDelivery] = useState(false);
  const [estimatedPrice, setEstimatedPrice] = useState(5000);

  // Recalculate estimated price dynamically based on user interaction
  useEffect(() => {
    const basePlan = pricingPlans.find(p => p.id === selectedPlanId);
    if (!basePlan) return;

    let basePrice = basePlan.price;
    let extraCosts = 0;

    // Check base page limits
    const basePagesLimit = selectedPlanId === 'starter' ? 1 : selectedPlanId === 'professional' ? 5 : 10;
    if (pagesCount > basePagesLimit) {
      extraCosts += (pagesCount - basePagesLimit) * 300; // ₹300 per extra page
    }

    // Additional add-ons
    if (includeSEO && selectedPlanId === 'starter') extraCosts += 600; // SEO is extra on starter plan
    if (includeCMS && selectedPlanId !== 'premium') extraCosts += 1200; // CMS costs extra on starter/professional
    if (includeSpeedOpt && selectedPlanId === 'starter') extraCosts += 500; // Speed optim is extra on starter
    if (expressDelivery) extraCosts += 1000; // Express speed is ₹1000 premium

    setEstimatedPrice(basePrice + extraCosts);
  }, [selectedPlanId, pagesCount, includeSEO, includeCMS, includeSpeedOpt, expressDelivery]);

  // Handle plan slider range adjustments based on selected core plan
  useEffect(() => {
    const defaultPages = selectedPlanId === 'starter' ? 1 : selectedPlanId === 'professional' ? 5 : 10;
    setPagesCount(defaultPages);
  }, [selectedPlanId]);

  const handleApplyEstimate = () => {
    const planName = selectedPlanId.charAt(0).toUpperCase() + selectedPlanId.slice(1);
    const details = `Estimated Code: Custom ${planName} Web, Pages: ${pagesCount}, SEO: ${includeSEO ? 'Yes' : 'No'}, CMS: ${includeCMS ? 'Yes' : 'No'}, Performance Boost: ${includeSpeedOpt ? 'Yes' : 'No'}, Express: ${expressDelivery ? 'Yes' : 'No'}`;
    onSelectPlanAndPrice(`Custom ${planName} Plan`, estimatedPrice, details);
  };

  return (
    <section
      id="pricing"
      className="py-24 bg-[#020617] relative overflow-hidden"
    >
      {/* Background aesthetics */}
      <div className="absolute top-1/4 right-0 w-[450px] h-[450px] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-[350px] h-[350px] bg-sky-600/5 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
            <Calculator className="w-3.5 h-3.5" />
            <span>Honest & Transparent Costs</span>
          </div>
          
          <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
            Flat Pricing Plans. No{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Hidden Contracts.
            </span>
          </h2>
          
          <p className="font-sans text-sm sm:text-base text-slate-400 mt-4 leading-relaxed">
            Choose a premium high-performing boilerplate layout below, or slide the interactive estimator nodes to simulate custom features instantly.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20" id="pricing-plans-grid">
          {pricingPlans.map((plan) => (
            <div
              key={plan.id}
              className={`relative sleek-card p-6 sm:p-8 flex flex-col justify-between ${
                plan.popular
                  ? 'border-blue-500/80 shadow-[0_0_25px_rgba(37,99,235,0.2)] lg:-translate-y-2'
                  : ''
              }`}
              id={`plan-card-${plan.id}`}
            >
              {plan.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-blue-600 border border-blue-400 text-white font-sans text-xs font-bold px-3.5 py-1 rounded-full flex items-center gap-1 shadow-md shadow-blue-500/15">
                  <Sparkles className="w-3.5 h-3.5" />
                  Most Popular Choice
                </div>
              )}

              <div>
                {/* Plan Header */}
                <div className="text-left mt-2">
                  <h3 className="font-sans font-bold text-lg text-white">{plan.name}</h3>
                  <p className="font-sans text-xs text-slate-400 mt-2 min-h-[36px]">
                    {plan.description}
                  </p>
                </div>

                {/* Price Display */}
                <div className="text-left mt-6 py-4 border-y border-slate-900/80 flex items-baseline">
                  <span className="font-sans font-extrabold text-white text-4xl sm:text-5xl tracking-tight">
                    ₹{plan.price.toLocaleString('en-IN')}
                  </span>
                  <span className="font-sans text-slate-500 text-xs ml-2 font-medium">
                    / One-Time Fixed
                  </span>
                </div>

                {/* Logistics */}
                <div className="flex gap-4 items-center justify-start mt-4 font-mono text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                  <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800">
                    ⏱️ {plan.deliveryTime}
                  </span>
                  <span className="bg-slate-900 px-2 py-1 rounded border border-slate-800">
                    🔄 {plan.revisions}
                  </span>
                </div>

                {/* Features Checklist */}
                <ul className="space-y-3.5 mt-8 text-left">
                  {plan.features.map((feature, idx) => (
                    <li
                      key={idx}
                      className={`flex items-start text-xs ${
                        feature.included ? 'text-slate-300' : 'text-slate-600 line-through'
                      }`}
                    >
                      {feature.included ? (
                        <Check className="w-4 h-4 text-emerald-500 mr-2.5 shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-4 h-4 text-slate-700 mr-2.5 shrink-0 mt-0.5" />
                      )}
                      <span className="leading-tight">{feature.name}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onSelectPlanAndPrice(plan.name, plan.price, `Core Selection: ${plan.name} Package`)}
                className={`w-full text-center py-3.5 px-4 rounded-xl font-sans text-sm font-bold transition-all mt-8 cursor-pointer outline-none ${
                  plan.popular
                    ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/10 active:scale-[0.98]'
                    : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 active:scale-[0.98]'
                }`}
                id={`plan-btn-${plan.id}`}
              >
                <span>Select {plan.name}</span>
              </button>
            </div>
          ))}
        </div>

        {/* Dynamic Pricing Estimator Container */}
        <div
          className="sleek-card p-6 sm:p-10 relative overflow-hidden text-left"
          id="custom-pricing-estimator"
        >
          {/* Subtle decoration gradient */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Control Form panel */}
            <div className="lg:col-span-7 space-y-6">
              <div className="flex items-center space-x-2 mb-2">
                <Sliders className="w-5 h-5 text-blue-400" />
                <h3 className="font-sans font-bold text-lg sm:text-xl text-white">
                  Interactive Web Quote Simulator
                </h3>
              </div>
              
              <p className="font-sans text-xs sm:text-sm text-slate-400 leading-relaxed">
                Tune specific layout features below. Watch our pricing algorithm update instantly to fit your precise digital roadmap!
              </p>

              {/* Step 1: Base Tier Link */}
              <div className="space-y-2">
                <label className="font-sans text-xs font-extrabold uppercase tracking-wider text-slate-400 block">
                  1. Select Baseline Foundation Package:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['starter', 'professional', 'premium'] as const).map((tier) => (
                    <button
                      key={tier}
                      onClick={() => setSelectedPlanId(tier)}
                      className={`py-3.5 px-2 text-center rounded-xl font-sans text-xs font-bold border transition-all cursor-pointer capitalize ${
                        selectedPlanId === tier
                          ? 'bg-blue-600/10 border-blue-500 text-blue-300'
                          : 'bg-slate-900/40 border-slate-900 text-slate-400 hover:text-slate-200 hover:border-slate-800'
                      }`}
                      id={`estimator-tier-${tier}`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Slider for Page Ranges */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-sans font-extrabold uppercase tracking-wider text-slate-400">
                    2. Quantity Of Pages Required:
                  </label>
                  <span className="font-mono font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-900/40">
                    {pagesCount} {pagesCount === 1 ? 'Page' : 'Pages'} Max
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="15"
                  value={pagesCount}
                  onChange={(e) => setPagesCount(Number(e.target.value))}
                  className="w-full accent-blue-500 cursor-ew-resize bg-slate-900 rounded-lg h-2"
                  id="estimator-page-slider"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-500 uppercase">
                  <span>1 Page (Landing)</span>
                  <span>5 Pages (Std Business)</span>
                  <span>10 Pages (Comprehensive)</span>
                  <span>15 Pages max</span>
                </div>
              </div>

              {/* Step 3: Add-on Checkbox Grid */}
              <div className="space-y-2.5 pt-2">
                <label className="font-sans text-xs font-extrabold uppercase tracking-wider text-slate-400 block">
                  3. Select High-Converting Add-ons:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* SEO checkbox */}
                  <label htmlFor="chk-seo" className="flex items-center space-x-3 p-3 bg-slate-900/40 border border-slate-900 hover:border-slate-800/80 rounded-xl cursor-pointer select-none">
                    <input
                      id="chk-seo"
                      type="checkbox"
                      checked={includeSEO}
                      onChange={(e) => setIncludeSEO(e.target.checked)}
                      className="w-4.5 h-4.5 rounded border-slate-800 text-blue-600 focus:ring-blue-500/40 accent-blue-500"
                    />
                    <div className="flex flex-col text-left">
                      <span className="font-sans text-xs font-bold text-slate-200">Local SEO Ready</span>
                      <span className="font-mono text-[9px] text-slate-500">Google Rank Infrastructure</span>
                    </div>
                  </label>

                  {/* CMS checkbox */}
                  <label htmlFor="chk-cms" className="flex items-center space-x-3 p-3 bg-slate-900/40 border border-slate-900 hover:border-slate-800/80 rounded-xl cursor-pointer select-none">
                    <input
                      id="chk-cms"
                      type="checkbox"
                      checked={includeCMS}
                      onChange={(e) => setIncludeCMS(e.target.checked)}
                      className="w-4.5 h-4.5 rounded border-slate-800 text-blue-600 focus:ring-blue-500/40 accent-blue-500"
                    />
                    <div className="flex flex-col text-left">
                      <span className="font-sans text-xs font-bold text-slate-200">Admin Dashboard CMS</span>
                      <span className="font-mono text-[9px] text-slate-500">Manage Menus, Classes & Blogs</span>
                    </div>
                  </label>

                  {/* Speed check */}
                  <label htmlFor="chk-speed" className="flex items-center space-x-3 p-3 bg-slate-900/40 border border-slate-900 hover:border-slate-800/80 rounded-xl cursor-pointer select-none">
                    <input
                      id="chk-speed"
                      type="checkbox"
                      checked={includeSpeedOpt}
                      onChange={(e) => setIncludeSpeedOpt(e.target.checked)}
                      className="w-4.5 h-4.5 rounded border-slate-800 text-blue-600 focus:ring-blue-500/40 accent-blue-500"
                    />
                    <div className="flex flex-col text-left">
                      <span className="font-sans text-xs font-bold text-slate-200">Express Performance Boost</span>
                      <span className="font-mono text-[9px] text-slate-500">95+ PageSpeed Index Score</span>
                    </div>
                  </label>

                  {/* Delivery priority */}
                  <label htmlFor="chk-express" className="flex items-center space-x-3 p-3 bg-slate-900/40 border border-slate-900 hover:border-slate-800/80 rounded-xl cursor-pointer select-none">
                    <input
                      id="chk-express"
                      type="checkbox"
                      checked={expressDelivery}
                      onChange={(e) => setExpressDelivery(e.target.checked)}
                      className="w-4.5 h-4.5 rounded border-slate-800 text-blue-600 focus:ring-blue-500/40 accent-blue-500"
                    />
                    <div className="flex flex-col text-left">
                      <span className="font-sans text-xs font-bold text-slate-200">Express Turnaround (48h)</span>
                      <span className="font-mono text-[9px] text-slate-500">Priority Design Rush Queue</span>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Live Pricing results widget */}
            <div className="lg:col-span-5 bg-blue-600/10 border border-blue-500/35 p-6 sm:p-8 rounded-2xl flex flex-col justify-between h-full min-h-[300px] text-center lg:text-left relative shadow-[inset_0_0_25px_rgba(37,99,235,0.15)] backdrop-blur-md">
              <div>
                <span className="font-mono text-[10px] text-blue-400 bg-blue-950 px-2.5 py-1.5 rounded-full border border-blue-900/40 font-bold uppercase tracking-wider inline-block mb-4">
                  💰 Simulated Value Estimation
                </span>
                
                <p className="font-sans text-xs text-slate-400 capitalize">
                  Estimated Pricing Code ({selectedPlanId} plan based)
                </p>

                <div className="mt-4 flex items-baseline justify-center lg:justify-start">
                  <span className="font-sans font-extrabold text-white text-4xl sm:text-5xl tracking-tight">
                    ₹{estimatedPrice.toLocaleString('en-IN')}
                  </span>
                  <span className="text-slate-500 text-xs ml-2 font-medium font-mono">
                    INR
                  </span>
                </div>

                {/* Simulated list of choices */}
                <div className="mt-6 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-300 py-1 border-b border-slate-900/60">
                    <span className="text-slate-400">Baseline Plan Price:</span>
                    <span className="font-mono text-slate-200">
                      ₹{pricingPlans.find(p => p.id === selectedPlanId)?.price.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-300 py-1 border-b border-slate-900/60">
                    <span className="text-slate-400">Total Configured Pages ({pagesCount}):</span>
                    <span className="font-mono text-slate-200">
                      Include ({pagesCount})
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400 py-1">
                    <span>Active Features:</span>
                    <span className="font-mono text-[11px] text-emerald-400">
                      {includeSEO ? '+SEO ' : ''}
                      {includeCMS ? '+CMS ' : ''}
                      {includeSpeedOpt ? '+Speed' : ''}
                    </span>
                  </div>
                </div>
              </div>

              {/* CTA trigger transfer to Contact */}
              <div className="mt-8">
                <button
                  onClick={handleApplyEstimate}
                  className="w-full flex items-center justify-center gap-2 py-4 px-4 bg-blue-600 hover:bg-blue-500 text-white font-sans font-bold rounded-xl shadow-lg shadow-blue-500/10 hover:shadow-blue-500/20 active:scale-98 transition-all cursor-pointer outline-none"
                  id="estimator-apply-btn"
                >
                  <span>Apply Estimate to Quote Form</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <span className="text-[10px] text-slate-500 text-center block mt-2 font-mono">
                  🔒 No obligation. Pre-fills contact details seamlessly.
                </span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
