/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Target, Users, Landmark, Heart, Shield } from 'lucide-react';

export default function About() {
  return (
    <section
      id="about"
      className="py-24 bg-[#020617] relative overflow-hidden text-left"
    >
      {/* Background spotlights */}
      <div className="absolute top-[20%] right-0 w-80 h-80 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Left panel: Visual info display blocks */}
          <div className="space-y-6" id="about-visual-cards">
            {/* Embedded illustration display */}
            <div className="sleek-card p-8 relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-44 h-44 bg-blue-600/10 rounded-full blur-2xl" />
              
              <span className="font-mono text-[10px] text-blue-500 font-extrabold uppercase tracking-widest block mb-1">
                OUR CORPORATE DNA
              </span>
              
              <h3 className="font-sans font-extrabold text-2xl text-white tracking-tight">
                Designed to Level the Digital Playing Field
              </h3>
              
              <p className="font-sans text-xs text-slate-400 mt-4 leading-relaxed">
                Most agencies charge massive margins for simple layouts. We operate on streamlined templates and highly optimized custom code stacks, reducing overhead to pass the savings onto hard-working local business owners.
              </p>

              {/* Pillars sub grid */}
              <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-slate-900/60">
                <div className="flex gap-3 items-start">
                  <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500">
                    <Target className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <span className="font-sans font-bold text-xs text-white block">Mission</span>
                    <span className="font-sans text-[11px] text-slate-500 block mt-0.5">High-converting pages</span>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500">
                    <Shield className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <span className="font-sans font-bold text-xs text-white block">Guarantees</span>
                    <span className="font-sans text-[11px] text-slate-500 block mt-0.5">Transparent flat pricing</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick value grids */}
            <div className="grid grid-cols-3 gap-4">
              <div className="sleek-card p-4 text-center">
                <span className="font-mono text-xl text-blue-400 font-extrabold block">24/7</span>
                <span className="font-sans text-[10px] text-slate-550 uppercase font-semibold block mt-1">Setup Help</span>
              </div>
              <div className="sleek-card p-4 text-center">
                <span className="font-mono text-xl text-emerald-400 font-extrabold block">100%</span>
                <span className="font-sans text-[10px] text-slate-550 uppercase font-semibold block mt-1">SEO Indexed</span>
              </div>
              <div className="sleek-card p-4 text-center">
                <span className="font-mono text-xl text-purple-400 font-extrabold block">0%</span>
                <span className="font-sans text-[10px] text-slate-550 uppercase font-semibold block mt-1">Hidden Costs</span>
              </div>
            </div>
          </div>

          {/* Right panel: Written Narrative block */}
          <div className="space-y-6">
            <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
              <Users className="w-3.5 h-3.5" />
              <span>About Adi Web Studio</span>
            </div>

            <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
              A Modern Digital Engine with{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400 font-extrabold">
                Local Values
              </span>
            </h2>

            <div className="space-y-4 font-sans text-xs sm:text-sm text-slate-350 leading-relaxed">
              <p>
                Founded on the belief that a premium, converting website shouldn’t cost a fortune, <strong>Adi Web Studio</strong> was created specifically to support local restaurants, pharmacies, education academies, saloon owners, and retail shops.
              </p>
              <p>
                We understand that running a traditional workspace demands extreme focus. You shouldn’t have to learn code, worry about DNS settings, or lose sleep over website security. We handle the entire layout design, hosting configuration, SEO indexation, and domain syncing quietly on your behalf.
              </p>
              <p>
                Our structural framework centers on clarity. By keeping our plans fixed between <strong>₹4,000 and ₹6,000</strong>, we ensure you always understand your digital expenses upfront. No retainer surprises, no monthly coding overhead. Just beautiful websites designed to do one simple thing: <strong>help your business grow.</strong>
              </p>
            </div>

            <div className="pt-4 flex flex-wrap gap-4 items-center">
              <div className="flex items-center space-x-3 bg-blue-900/15 border border-blue-800/40 px-4 py-3 rounded-xl">
                <Landmark className="w-5 h-5 text-blue-400" />
                <span className="font-sans text-xs font-bold text-white">
                  Built for Small Businesses & Professionals
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
