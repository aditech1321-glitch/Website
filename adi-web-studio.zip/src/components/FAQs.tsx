/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { faqs } from '../data';
import { HelpCircle, ChevronDown, ChevronUp, Plus, Minus, Info } from 'lucide-react';

export default function FAQs() {
  const [openIds, setOpenIds] = useState<string[]>(['faq-1']); // First one open by default
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Pricing' | 'Delivery' | 'Support' | 'Management' | 'Hosting'>('All');

  const categories = ['All', 'Pricing', 'Delivery', 'Support', 'Management', 'Hosting'];

  const filteredFaqs = selectedCategory === 'All'
    ? faqs
    : faqs.filter(faq => faq.category === selectedCategory);

  const toggleFaq = (id: string) => {
    if (openIds.includes(id)) {
      setOpenIds(openIds.filter(oId => oId !== id));
    } else {
      setOpenIds([...openIds, id]);
    }
  };

  return (
    <section
      id="faq"
      className="py-24 bg-[#020617] relative overflow-hidden text-left"
    >
      {/* Decorative gradients */}
      <div className="absolute top-1/4 left-0 w-80 h-80 bg-blue-900/5 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header content */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Got Questions? Ask Us</span>
          </div>
          
          <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
            Frequently Asked{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
              Questions
            </span>
          </h2>
          
          <p className="font-sans text-sm text-slate-400 mt-4 leading-relaxed">
            Everything you need to know about our flat pricing schemes, timelines, unlimited revision structures, and hosting parameters.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat as any)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-sans font-bold border transition-all duration-200 cursor-pointer outline-none ${
                selectedCategory === cat
                  ? 'bg-blue-600 border-blue-500 text-white shadow-lg'
                  : 'bg-slate-900/40 border-slate-900 text-slate-400 hover:text-slate-200 hover:border-slate-800'
              }`}
              id={`faq-cat-${cat.toLowerCase()}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Accordions List */}
        <div className="space-y-4" id="faq-accordions-list">
          {filteredFaqs.map((faq) => {
            const isOpen = openIds.includes(faq.id);
            return (
              <div
                key={faq.id}
                className={`sleek-card overflow-hidden ${
                  isOpen ? 'border-blue-500/30' : ''
                }`}
                id={`faq-item-${faq.id}`}
              >
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full text-left py-5 px-6 flex items-center justify-between gap-4 font-sans font-bold text-sm sm:text-base text-white hover:text-blue-400 transition-colors focus:outline-none cursor-pointer"
                >
                  <span>{faq.question}</span>
                  <div className={`p-1.5 rounded-lg bg-slate-900 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-180 bg-blue-900/20 text-blue-400' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {/* Sliding Answer Panel using React state transitions */}
                <div
                  className={`overflow-hidden transition-all duration-350 ease-in-out ${
                    isOpen ? 'max-h-[300px] border-t border-slate-900/60 opacity-100' : 'max-h-0 opacity-0 pointer-events-none'
                  }`}
                >
                  <div className="p-6 font-sans text-xs sm:text-sm text-slate-405 leading-relaxed bg-[#020617]/30">
                    {faq.answer}
                    
                    {/* Tiny category metadata chip inside answer */}
                    <div className="mt-4 flex items-center gap-1.5 text-[10px] uppercase font-mono font-semibold text-slate-500">
                      <Info className="w-3.5 h-3.5 text-blue-500" />
                      <span>Topic: {faq.category} Setup</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
