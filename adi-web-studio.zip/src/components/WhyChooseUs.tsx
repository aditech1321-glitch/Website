/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { whyChooseUs } from '../data';
import * as LucideIcons from 'lucide-react';

export default function WhyChooseUs() {
  // Dynamic icon rendering helper
  const renderIcon = (name: string, className: string) => {
    const IconComponent = (LucideIcons as any)[name];
    if (IconComponent) {
      return <IconComponent className={className} />;
    }
    return <LucideIcons.CheckCircle className={className} />;
  };

  return (
    <section
      id="why-choose-us"
      className="py-24 bg-[#030712] relative overflow-hidden text-left"
    >
      {/* Background radial effects */}
      <div className="absolute top-[30%] left-10 w-96 h-96 bg-blue-900/10 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-16">
          <div className="lg:col-span-7">
            <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono font-bold px-3 py-1.5 rounded-full uppercase tracking-wider mb-4">
              <LucideIcons.ShieldCheck className="w-3.5 h-3.5" />
              <span>Engineered For High Growth</span>
            </div>
            
            <h2 className="font-sans font-extrabold text-white text-3xl sm:text-4xl tracking-tight leading-tight">
              Why Creative Brands & Local Businesses{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">
                Partner With Us
              </span>
            </h2>
          </div>
          
          <div className="lg:col-span-5">
            <p className="font-sans text-xs sm:text-sm text-slate-400 leading-relaxed">
              We eliminate the overhead of standard agencies. There are no bloated consulting costs, or endless phone calls. Just highly focused, premium design built to bring local customers through your door.
            </p>
          </div>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="why-choose-us-grid">
          {whyChooseUs.map((feature) => (
            <div
              key={feature.id}
              className="group relative sleek-card p-6"
              id={`why-card-${feature.id}`}
            >
              {/* Feature BG Spotlight */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none -z-10"
                style={{
                  background: `radial-gradient(180px circle at 40px 40px, ${feature.bgAccent}, transparent 100%)`
                }}
              />

              {/* Icon Container */}
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-6 border transition-transform duration-300 group-hover:scale-105"
                style={{
                  backgroundColor: feature.bgAccent,
                  borderColor: feature.bgAccent.replace('0.1', '0.25')
                }}
              >
                {/* Dynamically lookup icon */}
                {renderIcon(feature.iconName, 'w-6 h-6 text-blue-400')}
              </div>

              {/* Text */}
              <h3 className="font-sans font-bold text-lg text-white mb-2 group-hover:text-blue-300 transition-colors">
                {feature.title}
              </h3>
              
              <p className="font-sans text-xs text-slate-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Dynamic Trust Stat Line */}
        <div className="mt-16 bg-gradient-to-r from-slate-950 via-[#0a0f24] to-slate-950 border border-slate-900 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-around gap-6 text-center">
          <div>
            <span className="font-mono text-3xl sm:text-4xl text-white font-extrabold block">
              100%
            </span>
            <span className="font-sans text-xs text-slate-400 tracking-wide uppercase mt-1 block">
              Satisfaction Gaurantee
            </span>
          </div>
          <div className="w-px h-10 bg-slate-800 hidden sm:block" />
          
          <div>
            <span className="font-mono text-3xl sm:text-4xl text-white font-extrabold block">
              4.9★
            </span>
            <span className="font-sans text-xs text-slate-400 tracking-wide uppercase mt-1 block">
              Avg Client Rating
            </span>
          </div>
          <div className="w-px h-10 bg-slate-800 hidden sm:block" />

          <div>
            <span className="font-mono text-3xl sm:text-4xl text-white font-extrabold block text-blue-500">
              ₹4k
            </span>
            <span className="font-sans text-xs text-slate-400 tracking-wide uppercase mt-1 block">
              Affordable Starting Cost
            </span>
          </div>
        </div>

      </div>
    </section>
  );
}
