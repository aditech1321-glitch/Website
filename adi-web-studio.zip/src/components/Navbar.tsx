/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, Sparkles } from 'lucide-react';

interface NavbarProps {
  onQuoteClick: () => void;
}

export default function Navbar({ onQuoteClick }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);

      // Simple active link tracker
      const sections = ['home', 'services', 'pricing', 'about', 'contact'];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'About', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav
      id="main-navbar"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'sleek-panel border-b border-white/5 py-3 shadow-lg shadow-black/30'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            onClick={(e) => handleLinkClick(e, '#home')}
            className="flex items-center space-x-2 group focus:outline-none"
            id="nav-logo"
          >
            <div className="relative w-9 h-9 flex items-center justify-center bg-blue-600 rounded-lg shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform duration-200">
              <Sparkles className="w-5 h-5 text-white" />
              <div className="absolute inset-0 bg-blue-400 rounded-lg blur-sm opacity-0 group-hover:opacity-30 transition-opacity duration-200" />
            </div>
            <div className="flex flex-col">
              <span className="font-sans font-bold text-lg md:text-xl text-white tracking-tight leading-none">
                Adi Web <span className="text-blue-500">Studio</span>
              </span>
              <span className="font-mono text-[9px] text-slate-400 font-medium tracking-wider uppercase leading-none mt-1">
                Agency
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className={`font-sans text-sm font-medium transition-colors relative py-1 focus:outline-none ${
                  activeSection === link.href.replace('#', '')
                    ? 'text-blue-400'
                    : 'text-slate-300 hover:text-white'
                }`}
                id={`desktop-link-${link.name.toLowerCase()}`}
              >
                {link.name}
                {activeSection === link.href.replace('#', '') && (
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 rounded-full" />
                )}
              </a>
            ))}
          </div>

          {/* Desktop CTA Button */}
          <div className="hidden md:block">
            <button
              onClick={onQuoteClick}
              className="group relative inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-sans text-sm font-semibold rounded-lg overflow-hidden transition-all duration-300 sleek-button-glow active:scale-[0.98] outline-none cursor-pointer focus:ring-2 focus:ring-blue-500/50"
              id="desktop-cta-btn"
            >
              <span className="relative z-10 flex items-center gap-1.5">
                Get Free Quote
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-indigo-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-0" />
            </button>
          </div>

          {/* Mobile Menu Actions */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-300 hover:text-white p-2 focus:outline-none transition-colors rounded-lg border border-slate-800 bg-slate-900/40"
              aria-label="Toggle menu"
              id="mobile-menu-toggle"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sliding Menu */}
      <div
        className={`md:hidden fixed inset-x-0 top-[70px] bg-slate-950/95 border-b border-slate-900 shadow-xl backdrop-blur-lg transition-all duration-350 ease-in-out ${
          isOpen ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
        id="mobile-navigation-dropdown"
      >
        <div className="px-4 pt-4 pb-6 space-y-3">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className={`block px-4 py-2.5 rounded-lg font-sans text-base font-semibold transition-all ${
                activeSection === link.href.replace('#', '')
                  ? 'bg-blue-600/10 text-blue-400 border-l-4 border-blue-500'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
              id={`mobile-link-${link.name.toLowerCase()}`}
            >
              {link.name}
            </a>
          ))}
          <div className="pt-4 border-t border-slate-900 px-4">
            <button
              onClick={() => {
                setIsOpen(false);
                onQuoteClick();
              }}
              className="w-full justify-center inline-flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-sans font-bold rounded-lg transition-colors shadow-md shadow-blue-500/10"
              id="mobile-cta-btn"
            >
              Get Free Quote
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
