/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Service, PricingPlan, WhyChooseUsItem, Testimonial, FAQItem } from './types';

export const agencyServices: Service[] = [
  {
    id: 'pharmacy-websites',
    title: 'Pharmacy Websites',
    description: 'Trustworthy and highly professional digital templates with details on pharmaceutical items, upload forms for doctor prescriptions, and hours of operation.',
    price: '₹5,000',
    iconName: 'HeartPulse',
    category: 'Local Business',
    features: ['Prescription Upload Tool', 'Interactive Medical Item List', 'Emergency Contact & Maps', 'Mobile Responsive Layout', 'SEO Keyword Optimization'],
    deliveryTime: '4-5 Days'
  },
  {
    id: 'restaurant-websites',
    title: 'Restaurant Websites',
    description: 'Gorgeously responsive portals with full digital menus, custom reservation widgets, map alignments, and dynamic special dishes carousels.',
    price: '₹5,000',
    iconName: 'Utensils',
    category: 'Local Business',
    features: ['Interactive Food Menus', 'Online Reservation Form', 'Google Maps Alignment', 'Call-to-Order Widgets', 'Social-Media Integration'],
    deliveryTime: '4-5 Days'
  },
  {
    id: 'education-websites',
    title: 'Education Websites',
    description: 'Perfect for academies, private coaches, tuition programs, and primary institutions to present classes, course timings, batch results, and maps.',
    price: '₹5,000',
    iconName: 'GraduationCap',
    category: 'Education',
    features: ['Course Catalogue Display', 'Student Registration Forms', 'Testimonials Slate', 'Syllabus/PDF Downloading', 'Batch Timetables & Plans'],
    deliveryTime: '4-5 Days'
  },
  {
    id: 'portfolio-websites',
    title: 'Portfolio Websites',
    description: 'Clean personal and business showcases with projects, services lists, about backgrounds, and customized intake forms for creatives and builders.',
    price: '₹4,000',
    iconName: 'Briefcase',
    category: 'Creative',
    features: ['Modern Elegant Typography', 'Interactive Work Case Studies', 'Contact Lead Interfaces', 'Downloadable PDF Resumes', 'Social Handles Grid'],
    deliveryTime: '3-4 Days'
  },
  {
    id: 'saloon-websites',
    title: 'Saloon Shops Websites',
    description: 'Beautiful, sleek web outlines for local saloons, spas, and wellness studios to list treatment menus, hair stylists, and direct booking inquiries.',
    price: '₹4,000',
    iconName: 'Scissors',
    category: 'Local Business',
    features: ['Sleek Treatment Catalog', 'Stylist/Provider Spotlights', 'Interactive Reservation Line', 'Instagram Feed Alignment', 'Full Mobile Optimizations'],
    deliveryTime: '3-4 Days'
  },
  {
    id: 'grocery-websites',
    title: 'Grocery Shops Websites',
    description: 'Feature-rich designs for grocery marts, supermarkets, and local vendors to display inventories, daily discount coupons, and contact routes.',
    price: '₹4,000',
    iconName: 'ShoppingCart',
    category: 'Retail & Shops',
    features: ['Product Inventory Display', 'Discount Spotlights Panel', 'Instant WhatsApp Ordering', 'Store Timings & Map Routes', 'Quick Search Filtering'],
    deliveryTime: '3-4 Days'
  },
  {
    id: 'footwear-websites',
    title: 'Footwear Shops Websites',
    description: 'Highly customized digital frames for footwear stores and shoe retailers to present collections, discount models, and contact buttons.',
    price: '₹4,000',
    iconName: 'Footprints',
    category: 'Retail & Shops',
    features: ['Visual Shoes Spotlight', 'Interactive Size & Stock Guides', 'Dynamic Inquiry Pathways', 'Local Store Location Sync', 'Season Deals Slider'],
    deliveryTime: '3-4 Days'
  },
  {
    id: 'clothing-websites',
    title: 'Clothing Shops Websites',
    description: 'Vibrant, optimized styling templates for fashion boutiques, apparel outlets, and ready-made clothing shops to display seasonal lookbooks.',
    price: '₹4,000',
    iconName: 'Shirt',
    category: 'Retail & Shops',
    features: ['Interactive Fashion Catalog', 'Filter by Clothing Categories', 'Direct order via WhatsApp', 'Store Locator Map Integration', 'Responsive Swipeable Lookbook'],
    deliveryTime: '3-4 Days'
  }
];

export const pricingPlans: PricingPlan[] = [
  {
    id: 'starter',
    name: 'Starter Plan',
    price: 4000,
    description: 'Perfect for local shops, individuals, and basic portfolios looking to establish a professional web presence quickly.',
    features: [
      { name: '1-Page Modern Design', included: true },
      { name: 'Fully Mobile-Friendly', included: true },
      { name: 'Basic SEO Setup', included: true },
      { name: 'Custom Contact Forms', included: true },
      { name: 'Hosting Integration Assistance', included: true },
      { name: 'Standard Delivery Speed', included: true },
      { name: 'Dynamic Admin Dashboard', included: false },
      { name: 'Advanced Speed Optimization', included: false },
      { name: 'Extended 6-Month Support', included: false }
    ],
    popular: false,
    deliveryTime: '3 Days',
    revisions: '3 Revisions'
  },
  {
    id: 'professional',
    name: 'Professional Plan',
    price: 5000,
    description: 'Ideal for local restaurants, pharmacies, education portals, salons, and retail shops requiring serious traffic attraction.',
    features: [
      { name: 'Up to 5 Pages Modern Design', included: true },
      { name: 'Fully Mobile-Friendly', included: true },
      { name: 'Local SEO Setup & Google Maps', included: true },
      { name: 'Advanced Interactive Forms', included: true },
      { name: 'Secure Domain & Hosting Link', included: true },
      { name: 'Fast Track Delivery (4-5 Days)', included: true },
      { name: 'Dynamic Admin Dashboard', included: false },
      { name: 'Advanced Speed Optimization', included: true },
      { name: 'Extended 6-Month Support', included: false }
    ],
    popular: true,
    deliveryTime: '4 Days',
    revisions: 'Unlimited Revisions'
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 6000,
    description: 'Designed for ambitious brands desiring full functionality, interactive menus, prescription uploading, dashboard capabilities, and top-tier SEO.',
    features: [
      { name: 'Up to 10 Pages Responsive Layout', included: true },
      { name: 'Fully Mobile-Friendly', included: true },
      { name: 'Premium Local & Global SEO Setup', included: true },
      { name: 'Advanced Features (CMS, Menus, Uploads)', included: true },
      { name: 'Secure Hosting Setup + Free SSL Integration', included: true },
      { name: 'Priority Express Delivery (3-4 Days)', included: true },
      { name: 'Dynamic Admin Dashboard Web-app', included: true },
      { name: 'Supercharged Speed Optimization (95+ score)', included: true },
      { name: 'Extended 6-Month Support & Backups', included: true }
    ],
    popular: false,
    deliveryTime: '4 Days',
    revisions: 'Unlimited Revisions'
  }
];

export const whyChooseUs: WhyChooseUsItem[] = [
  {
    id: 'affordable-pricing',
    title: 'Affordable Pricing',
    description: 'High-end agency levels of detail without the high-end cost starting at just ₹4,000. No hidden charges or recurring commissions.',
    iconName: 'CreditCard',
    bgAccent: 'rgba(59, 130, 246, 0.1)'
  },
  {
    id: 'fast-delivery',
    title: 'Fast Delivery',
    description: 'Receive your initial live preview, fully functioning, inside 3-5 days. We move fast so you can start selling online fast.',
    iconName: 'Zap',
    bgAccent: 'rgba(16, 185, 129, 0.1)'
  },
  {
    id: 'mobile-friendly',
    title: 'Mobile-Friendly Design',
    description: 'Over 65% of web audiences buy via mobile devices. Every site we build is engineered specifically to look breathtaking on mobile screens.',
    iconName: 'Smartphone',
    bgAccent: 'rgba(239, 68, 68, 0.1)'
  },
  {
    id: 'seo-ready',
    title: 'SEO Ready',
    description: 'Every layout includes structural schema, meta-tag mapping, fast performance metrics, and indexing triggers designed to capture local Google ranks.',
    iconName: 'TrendingUp',
    bgAccent: 'rgba(139, 92, 246, 0.1)'
  },
  {
    id: 'modern-ux',
    title: 'Modern User Experience',
    description: 'Interactive page movements, custom shadows, and elegant typography configurations designed to lock eyeballs and reduce page bounce.',
    iconName: 'LayoutGrid',
    bgAccent: 'rgba(245, 158, 11, 0.1)'
  },
  {
    id: 'dedicated-support',
    title: 'Dedicated Support',
    description: 'Complete hands-on setup support. Need minor modifications or guidance with domain hosting? We stand by you indefinitely.',
    iconName: 'Heart',
    bgAccent: 'rgba(236, 72, 153, 0.1)'
  }
];

export const clientTestimonials: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Dr. Ramesh Sharma',
    role: 'Managing Director',
    company: 'Sanjeevani Local Pharmacy',
    rating: 5,
    comment: 'Adi Web Studio built our website with a dedicated prescription upload form. It turned out incredibly clean and simple for older customers to use. Since launching, we have seen a 30% jump in home delivery inquiries! Unbelievable speed and affordability.',
    initials: 'RS'
  },
  {
    id: 'test-2',
    name: 'Priyanka Sen',
    role: 'Founder',
    company: 'Zenith Academic Coaching',
    rating: 5,
    comment: 'We struggled for months trying to build a website ourselves. Adi Web Studio took charge and delivered our course catalog website in just 4 days for just ₹5,000! Professional typography, flawless mobile layouts, and friendly support. Best decision we made.',
    initials: 'PS'
  },
  {
    id: 'test-3',
    name: 'Vikram Singh',
    role: 'Owner',
    company: 'The Clay Oven Restaurant',
    rating: 5,
    comment: 'The digital food menu on our new website is incredible. Customers can scan our QR code table cards and instantly view our specials on a gorgeously responsive page. Highly recommend their professional plan for local restaurants!',
    initials: 'VS'
  },
  {
    id: 'test-4',
    name: 'Karan Malhotra',
    role: 'Owner',
    company: 'Royal Touch Saloon & Spa',
    rating: 5,
    comment: 'Adi Web Studio built an outstanding website with a clean stylists directory and price lists for our beauty saloon. Our clients can now easily swipe through our services and book appointments directly. Extremely fast setup!',
    initials: 'KM'
  }
];

export const faqs: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'How much does a website cost, and are there any hidden fees?',
    answer: 'Our pricing plans are transparent starting at ₹4,000 (Starter Plan), ₹5,000 (Professional Plan), and ₹6,000 (Premium Plan). There are zero hidden fees. The final price you see is exactly what you pay. Hosting and domain are purchased by you, and we link them completely free of charge.',
    category: 'Pricing'
  },
  {
    id: 'faq-2',
    question: 'How fast will my website be delivered?',
    answer: 'Standard delivery times are 3 days for our starter page, 4 days for our professional package, and 4-5 days for customized premium setups. If you have an urgent deadline, let us know and we will prioritize your build.',
    category: 'Delivery'
  },
  {
    id: 'faq-3',
    question: 'What happens if I need changes after the website is built?',
    answer: 'We provide revisions based on your plan (3 changes for Starter, Unlimited for Professional & Premium) to ensure you are fully satisfied. We also include up to 30 days of free post-launch support to resolve any minor questions or glitches.',
    category: 'Support'
  },
  {
    id: 'faq-4',
    question: 'Will I be able to update my grocery list, salon services, menus, or footwear stock myself?',
    answer: 'Yes! For our plans, we construct extremely simple tables, text sections, or WhatsApp-activated catalogs so that you can update products, services, footwear designs, or food menus easily without any technical coding knowledge.',
    category: 'Management'
  },
  {
    id: 'faq-5',
    question: 'Is the website hosted permanently for free?',
    answer: 'We assist you in configuring super-affordable, professional hosting platforms (including premium Google Firebase hosting or Vercel which both contain a massive forever-free tier for static websites!). This saves you hundreds compiled yearly.',
    category: 'Hosting'
  },
  {
    id: 'faq-6',
    question: 'Will my website look good on mobile devices and iPhones?',
    answer: 'Aero-mobile functionality is a absolute standard at Adi Web Studio. Every layout is strictly tested across multiple pixel densities, screen aspects, Safari/Chrome browsers, and tablets to guarantee a native app-like desktop feel.',
    category: 'Development'
  }
];
