/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Pricing from './components/Pricing';
import About from './components/About';
import Testimonials from './components/Testimonials';
import FAQs from './components/FAQs';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { ArrowUp, Sparkles, AlertCircle, ShoppingBag } from 'lucide-react';

export default function App() {
  // Prefilled parameters passed into the Inquiry Desk contact block
  const [prefilledPlan, setPrefilledPlan] = useState<string | undefined>(undefined);
  const [prefilledPrice, setPrefilledPrice] = useState<number | undefined>(undefined);
  const [prefilledDetails, setPrefilledDetails] = useState<string | undefined>(undefined);
  const [showStickyQuoteBtn, setShowStickyQuoteBtn] = useState(false);

  // Monitor scroll height to conditionally toggle high-converting back-to-top or sticky quote floaters
  useEffect(() => {
    const handleScroll = () => {
      // Show sticky button after scrolling past the Hero section
      setShowStickyQuoteBtn(window.scrollY > 600);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      window.scrollTo({
        top: element.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  const handleSelectPlanAndPrice = (planName: string, price: number, details: string) => {
    setPrefilledPlan(planName);
    setPrefilledPrice(price);
    setPrefilledDetails(details);
    scrollToSection('contact');
  };

  const handleSelectService = (serviceName: string) => {
    setPrefilledPlan(serviceName);
    setPrefilledPrice(undefined);
    setPrefilledDetails(`We are looking to configure a professional build for our own custom ${serviceName} project.`);
    scrollToSection('contact');
  };

  const handleQuoteClickFromNavbar = () => {
    setPrefilledPlan(undefined);
    setPrefilledPrice(undefined);
    setPrefilledDetails(undefined);
    scrollToSection('contact');
  };

  const handleClearPrefill = () => {
    setPrefilledPlan(undefined);
    setPrefilledPrice(undefined);
    setPrefilledDetails(undefined);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-white flex flex-col font-sans selection:bg-blue-600/35 selection:text-white" id="main-applet-root">
      {/* Sticky Top Navbar */}
      <Navbar onQuoteClick={handleQuoteClickFromNavbar} />

      {/* Main Sections Body */}
      <main className="flex-grow">
        {/* 1. Hero Presentation */}
        <Hero
          onQuoteClick={handleQuoteClickFromNavbar}
          onPricingClick={() => scrollToSection('pricing')}
        />

        {/* 2. Services Catalogue */}
        <Services onSelectService={handleSelectService} />

        {/* 3. Why Choose Us Bento Highlights */}
        <WhyChooseUs />

        {/* 4. Pricing Plans & Interactive Estimator */}
        <Pricing onSelectPlanAndPrice={handleSelectPlanAndPrice} />

        {/* 5. Vision / About Narrative */}
        <About />

        {/* 6. Realistic Client Testimonials */}
        <Testimonials />

        {/* 7. Accordion FAQs */}
        <FAQs />

        {/* 8. Conversion-Focused Contact Briefing */}
        <Contact
          prefilledPlan={prefilledPlan}
          prefilledPrice={prefilledPrice}
          prefilledDetails={prefilledDetails}
          onClearPrefill={handleClearPrefill}
        />
      </main>

      {/* 9. Footing Section */}
      <Footer />

      {/* Persistent Floating Quick-Convert Button */}
      <div
        className={`fixed bottom-6 right-6 z-40 transition-all duration-300 transform ${
          showStickyQuoteBtn ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-4 scale-90 pointer-events-none'
        }`}
        id="quick-query-floating-trigger"
      >
        <button
          onClick={handleQuoteClickFromNavbar}
          className="flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-sans text-xs font-extrabold rounded-full shadow-2xl shadow-blue-500/20 hover:shadow-blue-500/30 active:scale-95 transition-all outline-none cursor-pointer border border-blue-400/20"
        >
          <Sparkles className="w-4 h-4 animate-pulse text-amber-300" />
          <span>Get Free Quote</span>
        </button>
      </div>
    </div>
  );
}
