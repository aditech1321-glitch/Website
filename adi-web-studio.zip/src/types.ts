/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Service {
  id: string;
  title: string;
  description: string;
  price: string;
  iconName: string;
  category: string;
  features: string[];
  deliveryTime: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  description: string;
  features: { name: string; included: boolean }[];
  popular: boolean;
  deliveryTime: string;
  revisions: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  rating: number;
  comment: string;
  initials: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface WhyChooseUsItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  bgAccent: string;
}

export interface QuoteEstimation {
  planType: 'starter' | 'professional' | 'premium';
  pages: number;
  includeSEO: boolean;
  includeSupport: boolean;
  includeCMS: boolean;
  includeSpeedOptimization: boolean;
  estimatedTotal: number;
}
